package com.abuwalayh.walayh

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val textView = TextView(this).apply {
            text = "🛡️ Walayh Pro Suite"
            textSize = 24f
        }
        setContentView(textView)
    }
}
